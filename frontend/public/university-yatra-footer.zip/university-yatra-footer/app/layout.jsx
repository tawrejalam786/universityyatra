import "./globals.css";

export const metadata = { title: "University Yatra — Responsive Footer" };

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
