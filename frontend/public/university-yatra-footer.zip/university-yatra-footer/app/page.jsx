import UniversityFooter from "../components/UniversityFooter";

export default function Page() {
  return <UniversityFooter />;
}
