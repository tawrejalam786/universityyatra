import Image from "next/image";

const GROUPS = [
  {
    title: "Quick Links",
    links: [
      ["Home", "/"],
      ["About Us", "/about-us/"],
      ["FAQs", "/faqs/"],
      ["Contact Us", "/contact-us/"],
    ],
  },
  {
    title: "Student Services",
    links: [
      ["Study in India", "/study-in-india/"],
      ["Study Abroad", "/study-abroad/"],
      ["Student Services", "/contact-us/"],
      ["Loan & Scholarship Assistance", "/loan-and-scholarship-assistance/"],
      ["MBBS Abroad", "/mbbs-abroad/"],
    ],
  },
  {
    title: "Study Destinations",
    links: [
      ["Canada", "/study-in-canada/"],
      ["UK & Ireland", "/study-in-uk-ireland/"],
      ["Europe", "/study-in-europe/"],
      ["USA", "/study-in-usa/"],
    ],
  },
];

const POLICIES = [
  ["Privacy Policy", "/privacy-policy/"],
  ["Terms & Conditions", "/terms-conditions/"],
  ["Cancellation & Refund Policy", "/cancellation-refund-policy/"],
];

const FOCUS = "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#003870]";

function Icon({ name, className = "h-5 w-5" }) {
  const paths = {
    arrow: <path d="M4 12h16m-7-7 7 7-7 7" />,
    plus: <path d="M12 5v14M5 12h14" />,
    mail: <><rect x="3" y="5" width="18" height="14" rx="3" /><path d="m3 7 9 6 9-6" /></>,
    phone: <path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3.1 5.2 2 2 0 0 1 5.1 3h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L9 10.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 1.1Z" />,
    instagram: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r=".7" fill="currentColor" stroke="none" /></>,
    facebook: <path d="M14 22v-9h3l.5-4H14V6.5c0-1 .3-1.5 1.7-1.5H18V1.4A25 25 0 0 0 15 1c-3 0-5 1.8-5 5v3H7v4h3v9Z" fill="currentColor" stroke="none" />,
    youtube: <><rect x="2.5" y="5" width="19" height="14" rx="4" /><path d="m10 9 5 3-5 3Z" fill="currentColor" stroke="none" /></>,
    whatsapp: <><path d="M21 11.6a9 9 0 0 1-13.3 7.9L3 21l1.5-4.5A9 9 0 1 1 21 11.6Z" /><path d="M8 7.5c-.8.9-.3 3.3 1.8 5.4s4.5 2.6 5.4 1.8l.9-1.1-2.4-1.2-.8.8a8 8 0 0 1-2.9-2.9l.8-.8L9.6 7Z" /></>,
  };
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      {paths[name]}
    </svg>
  );
}

function LinkList({ links, hrefFor }) {
  return (
    <ul className="m-0 list-none space-y-0.5 p-0">
      {links.map(([label, path]) => (
        <li key={label}>
          <a href={hrefFor(path)} className={`inline-flex min-h-[44px] items-center rounded-sm py-2 text-[15px] leading-6 text-[#003870]/80 underline-offset-4 hover:text-[#003870] hover:underline ${FOCUS}`}>
            {label}
          </a>
        </li>
      ))}
    </ul>
  );
}

/**
 * Mobile-first Next.js / Tailwind footer. No extra packages or client JS.
 * Native details accordions work with touch, keyboard and JavaScript disabled.
 * Defaults point to the current website. Use siteUrl="" for local Next.js routes.
 */
export default function UniversityFooter({
  siteUrl = "https://universityyatra.com",
  logoSrc = "/images/footer/university-yatra-logo.png",
  skylineSrc = "/images/footer/global-skyline.png",
  phone = "+91 92868 44550",
  email = "info@universityyatra.com",
  whatsappNumber = "919286844550",
  contactHref,
  socialLinks = {},
  linkGroups = GROUPS,
  policyLinks = POLICIES,
  year = new Date().getFullYear(),
}) {
  const hrefFor = (path) => /^(https?:|mailto:|tel:|#)/i.test(path) ? path : `${siteUrl.replace(/\/$/, "")}${path}`;
  const phoneHref = `tel:${phone.replace(/[^+\d]/g, "")}`;
  const whatsappHref = `https://wa.me/${whatsappNumber.replace(/\D/g, "")}?text=${encodeURIComponent("Hi University Yatra, I would like guidance on my study options.")}`;
  const socials = [
    { name: "Instagram", icon: "instagram", href: socialLinks.instagram },
    { name: "Facebook", icon: "facebook", href: socialLinks.facebook },
    { name: "YouTube", icon: "youtube", href: socialLinks.youtube },
    { name: "WhatsApp", icon: "whatsapp", href: whatsappHref },
  ].filter((item) => item.href);

  return (
    <footer aria-label="University Yatra footer" className="overflow-hidden border-t border-[#2EBEB5]/20 bg-[#F3FAF9] text-[#003870]">
      <div className="mx-auto max-w-[1440px] px-5 pt-10 sm:px-8 sm:pt-14 lg:px-12 lg:pt-16">
        <div className="grid gap-7 border-b border-[#2EBEB5]/35 pb-8 md:grid-cols-[minmax(0,1fr)_auto] md:items-center md:gap-12 lg:pb-10">
          <div className="min-w-0">
            <a href={hrefFor("/")} aria-label="University Yatra home" className={`inline-block max-w-full rounded-md ${FOCUS}`}>
              <Image src={logoSrc} alt="University Yatra — Making Global Education Easy" width={1024} height={246} sizes="(min-width: 768px) 380px, 280px" className="h-auto w-[280px] max-w-full object-contain object-left md:w-[380px]" />
            </a>
            <p className="mb-0 mt-4 max-w-[37ch] text-[15px] leading-7 text-[#003870]/75 sm:text-base">
              Guiding students towards global education with support at every step.
            </p>
          </div>

          <div className="rounded-2xl border border-[#2EBEB5]/25 bg-[#2EBEB5]/[0.06] p-5 md:max-w-[340px] md:rounded-none md:border-0 md:bg-transparent md:p-0">
            <p className="m-0 text-[19px] font-semibold leading-7 tracking-[-0.02em] md:text-[18px]">Your next chapter starts here.</p>
            <a href={contactHref || hrefFor("/contact-us/")} className={`group mt-4 flex min-h-[52px] w-full items-center justify-center gap-4 rounded-xl bg-[#003870] px-5 py-3.5 text-[15px] font-semibold text-white transition-colors hover:bg-[#2EBEB5] hover:text-[#003870] motion-reduce:transition-none md:rounded-lg ${FOCUS}`}>
              Speak with our team
              <Icon name="arrow" className="h-5 w-5 shrink-0 motion-safe:transition-transform motion-safe:group-hover:translate-x-1" />
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 py-7 md:grid-cols-2 md:gap-x-12 md:gap-y-8 md:py-10 lg:grid-cols-[1fr_1.2fr_1.1fr_1.3fr] lg:gap-10">
          {linkGroups.map((group) => (
            <div key={group.title} className="min-w-0">
              {/* Only the mobile or desktop version is visible at a time. */}
              <details className="group border-b border-[#2EBEB5]/25 md:hidden">
                <summary className={`flex min-h-[58px] cursor-pointer list-none items-center justify-between gap-4 rounded-sm py-4 text-base font-semibold [&::-webkit-details-marker]:hidden ${FOCUS}`}>
                  {group.title}
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#2EBEB5]/10">
                    <Icon name="plus" className="h-4 w-4 group-open:rotate-45 motion-safe:transition-transform" />
                  </span>
                </summary>
                <nav aria-label={group.title} className="pb-4 pl-1"><LinkList links={group.links} hrefFor={hrefFor} /></nav>
              </details>
              <nav aria-label={group.title} className="hidden md:block">
                <h2 className="mb-3 mt-0 text-[18px] font-bold leading-7 tracking-[-0.02em]">{group.title}</h2>
                <LinkList links={group.links} hrefFor={hrefFor} />
              </nav>
            </div>
          ))}

          <div className="order-first min-w-0 pb-7 md:order-last md:pb-0">
            <h2 className="mb-3 mt-0 text-[18px] font-bold leading-7 tracking-[-0.02em]">Connect With Us</h2>
            <address className="not-italic">
              <a href={`mailto:${email}`} className={`flex min-h-[48px] items-center gap-3 rounded-lg text-[14px] leading-6 text-[#003870]/80 hover:underline sm:text-[15px] ${FOCUS}`}>
                <Icon name="mail" className="h-5 w-5 shrink-0" />
                <span className="min-w-0 break-words [overflow-wrap:anywhere]">{email}</span>
              </a>
              <a href={phoneHref} className={`flex min-h-[44px] items-center gap-3 rounded-lg text-[15px] text-[#003870]/80 hover:underline ${FOCUS}`}>
                <Icon name="phone" className="h-[18px] w-[18px] shrink-0" />{phone}
              </a>
            </address>

            <div className="mt-3 grid grid-cols-2 gap-3 md:hidden">
              <a href={phoneHref} className={`flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-[#003870]/20 bg-white px-3 py-3 text-sm font-semibold ${FOCUS}`}>
                <Icon name="phone" className="h-4 w-4" />Call us
              </a>
              <a href={whatsappHref} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp (opens a new tab)" className={`flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#2EBEB5] px-3 py-3 text-sm font-semibold ${FOCUS}`}>
                <Icon name="whatsapp" className="h-5 w-5" />WhatsApp
              </a>
            </div>

            <nav aria-label="Social media" className={`mt-5 flex-wrap gap-3 ${socials.length === 1 ? "hidden md:flex" : "flex"}`}>
              {socials.map((social) => (
                <a key={social.name} href={social.href} target="_blank" rel="noopener noreferrer" aria-label={`${social.name} (opens a new tab)`} className={`flex h-12 w-12 items-center justify-center rounded-full border border-[#2EBEB5]/20 bg-white text-[#003870] transition-colors hover:border-[#003870] hover:bg-[#003870] hover:text-white motion-reduce:transition-none ${FOCUS}`}>
                  <Icon name={social.icon} className="h-[22px] w-[22px]" />
                </a>
              ))}
            </nav>
          </div>
        </div>

        <div className="flex flex-col gap-5 border-t border-[#2EBEB5]/35 pt-5 md:pb-2 lg:flex-row lg:items-center lg:justify-between lg:gap-8">
          <p className="order-last m-0 max-w-[47ch] text-[12px] leading-6 text-[#003870]/75 sm:text-[13px] lg:order-first">
            © {year} University Yatra™. <span className="block sm:inline">A unit of Future Yatra PVT. LTD.</span>
          </p>
          <nav aria-label="Legal" className="flex flex-wrap gap-x-5 gap-y-0 lg:justify-end">
            {policyLinks.map(([label, path]) => (
              <a key={label} href={hrefFor(path)} className={`inline-flex min-h-[44px] items-center rounded-sm py-2 text-[12px] leading-5 text-[#003870]/85 underline-offset-4 hover:underline sm:text-[13px] ${FOCUS}`}>{label}</a>
            ))}
          </nav>
        </div>
      </div>

      {/* Decorative only. Wider mobile canvas keeps individual landmarks legible. */}
      <div aria-hidden="true" className="pointer-events-none mt-6 overflow-hidden select-none sm:mt-8">
        <Image src={skylineSrc} alt="" width={2172} height={724} sizes="(max-width: 639px) 680px, 100vw" className="relative left-1/2 block h-auto w-[680px] max-w-none -translate-x-1/2 sm:w-full" />
      </div>
    </footer>
  );
}
