# University Yatra — mobile-first footer

A Next.js JSX + Tailwind CSS recreation of your supplied footer. Uses navy #003870, teal #2EBEB5, a pale mint surface and neutral tones in the decorative artwork.

## Add to an existing Next.js project

1. Copy `components/UniversityFooter.jsx` into your components folder.
2. Copy `public/images/footer/` into your project's `public/images/` folder.
3. Import the footer below your page content or in your root layout. Do not replace your existing layout or global CSS with the demo files.

```jsx
import UniversityFooter from "@/components/UniversityFooter";

export default function Page() {
  return (
    <>
      <main>{/* Your existing page sections */}</main>
      <UniversityFooter />
    </>
  );
}
```

The default navigation links go to the existing universityyatra.com website. For routes hosted in your Next.js project, set `siteUrl=""` and ensure those routes exist:

```jsx
<UniversityFooter siteUrl="" contactHref="/contact-us" />
```

For a form on the same page, set `contactHref="#counselling"` and give the form that ID.

## Social links

WhatsApp works using the phone number supplied in your reference. Instagram, Facebook and YouTube profile URLs were not supplied or found in the website footer, so those icons appear only when configured. This avoids broken social links. Pass your actual profile URLs:

```jsx
<UniversityFooter
  socialLinks={{
    instagram: "YOUR_INSTAGRAM_PROFILE_URL",
    facebook: "YOUR_FACEBOOK_PAGE_URL",
    youtube: "YOUR_YOUTUBE_CHANNEL_URL",
  }}
/>
```

Replace the three placeholder strings before using this example. The footer includes each platform's SVG icon; no icon package is required.

## Mobile decisions

- Main CTA fills the available width with a 52px minimum touch target.
- Contact information comes before menus, with 48px Call and WhatsApp buttons.
- Quick Links, Student Services and Study Destinations are native expandable menus below 768px. They work without client-side JavaScript.
- At 768px menus are visible in a two-column grid; at 1024px the footer uses four columns.
- Policy links wrap and remain at least 44px tall.
- Artwork uses a 680px wide canvas on phones, cropped by the footer container. It cannot create horizontal page scrolling.
- Keyboard focus outlines and reduced-motion handling are included.

Native mobile accordions and desktop menus share the same link data. Only the appropriate version is visible or exposed to assistive technology at each breakpoint. The footer has no sticky overlay to cover page content.

## Customize

Props: `siteUrl`, `logoSrc`, `skylineSrc`, `phone`, `email`, `whatsappNumber`, `contactHref`, `socialLinks`, `linkGroups`, `policyLinks`, `year`.

`linkGroups` uses `{ title, links: [[label, path], ...] }` entries. `policyLinks` uses `[label, path]` pairs. All paths can also be absolute URLs. The generic Student Services item currently goes to Contact Us because the existing website's Student Services menu is a non-clickable parent; replace it if you create a dedicated services page. The copyright year defaults to the render year; pass a year from your layout if you cache the whole page across a year boundary.

The component inherits your website font. Tailwind must scan its location. On Tailwind 3 include your components directory in the existing `content` array; the included standalone demo uses Tailwind 4.

## Run the included standalone demo

For an instant preview, open `preview.html` in your browser. It includes all styles and images in one file; its mobile accordions work without setup. The screenshot-like layout uses real HTML text and links, and can be resized to check phone/tablet/desktop layouts.

Use the full folder only for a new standalone preview project:

```bash
npm install
npm run dev
```

Open http://localhost:3000. Production build: `npm run build`.

## Assets and sources

- Logo: downloaded unchanged from the existing University Yatra website: https://universityyatra.com/wp-content/uploads/2025/11/University-Yatra-Logo-transparent-background-scaled-1024x246.png
- Contact details and navigation paths: https://universityyatra.com/
- Skyline: newly generated transparent PNG in the style of the supplied reference, using the built-in image-generation tool. Generation prompt included in `ARTWORK-PROMPT.md`.

This is a Next.js component package, not an Elementor widget or a WordPress plugin. It does not change your live website.
